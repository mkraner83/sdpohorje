<?php

if (!defined('ABSPATH')) {
    exit;
}

class SDP_Accounts_Plugin
{
    const ATHLETE_ROLE = 'sdp_athlete';
    const PARENT_ROLE = 'sdp_parent';
    const STAFF_ROLE = 'sdp_staff';

    const META_STATUS = 'sdp_registration_status';
    const META_ROLE_TYPE = 'sdp_role_type';
    const META_CHILD_INFO = 'sdp_child_info';
    const META_PARENT_IDS = 'sdp_parent_ids';
    const META_ATHLETE_IDS = 'sdp_athlete_ids';
    const OPTION_ADMIN_NOTIFICATION_EMAIL = 'sdp_admin_notification_email';

    private static $instance = null;

    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate()
    {
        self::register_roles();
        flush_rewrite_rules();
    }

    public static function deactivate()
    {
        flush_rewrite_rules();
    }

    private static function register_roles()
    {
        add_role(
            self::ATHLETE_ROLE,
            'Athlete',
            array(
                'read' => true,
            )
        );

        add_role(
            self::PARENT_ROLE,
            'Parent',
            array(
                'read' => true,
            )
        );

        add_role(
            self::STAFF_ROLE,
            'Staff',
            array(
                'read' => true,
                'edit_posts' => true,
                'upload_files' => true,
            )
        );
    }

    private function __construct()
    {
        add_action('init', array($this, 'register_roles_runtime'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('init', array($this, 'handle_form_requests'));

        add_shortcode('sdp_register_athlete', array($this, 'render_athlete_registration'));
        add_shortcode('sdp_register_parent', array($this, 'render_parent_registration'));
        add_shortcode('sdp_login', array($this, 'render_login_form'));
        add_shortcode('sdp_forgot_password', array($this, 'render_forgot_password_form'));
        add_shortcode('sdp_reset_password', array($this, 'render_reset_password_form'));
        add_shortcode('sdp_dashboard', array($this, 'render_dashboard'));

        add_filter('authenticate', array($this, 'block_pending_users'), 30, 3);

        add_action('admin_menu', array($this, 'register_admin_pages'));
        add_action('admin_post_sdp_portal_save_settings', array($this, 'handle_admin_settings_save'));
        add_action('pre_get_users', array($this, 'filter_users_admin_lists'));
    }

    public function register_roles_runtime()
    {
        self::register_roles();
    }

    public function enqueue_assets()
    {
        wp_enqueue_style(
            'sdp-accounts-style',
            SDP_ACCOUNTS_URL . 'assets/css/sdp-accounts.css',
            array(),
            SDP_ACCOUNTS_VERSION
        );

        wp_enqueue_script(
            'sdp-accounts-script',
            SDP_ACCOUNTS_URL . 'assets/js/sdp-accounts.js',
            array(),
            SDP_ACCOUNTS_VERSION,
            true
        );
    }

    private function get_request_action()
    {
        if (!isset($_POST['sdp_action'])) {
            return '';
        }

        return sanitize_key(wp_unslash($_POST['sdp_action']));
    }

    public function handle_form_requests()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $action = $this->get_request_action();

        if ($action === 'register_athlete') {
            $this->handle_registration(self::ATHLETE_ROLE);
            return;
        }

        if ($action === 'register_parent') {
            $this->handle_registration(self::PARENT_ROLE);
            return;
        }

        if ($action === 'login') {
            $this->handle_login();
            return;
        }

        if ($action === 'forgot_password') {
            $this->handle_forgot_password();
            return;
        }

        if ($action === 'reset_password') {
            $this->handle_reset_password();
            return;
        }

        if ($action === 'update_profile') {
            $this->handle_profile_update();
        }
    }

    private function get_dashboard_url()
    {
        return home_url('/uporabniski-portal/');
    }

    private function nonce_ok($name)
    {
        return isset($_POST['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), $name);
    }

    private function redirect_with_message($type, $message)
    {
        $url = isset($_POST['sdp_return_url']) ? esc_url_raw(wp_unslash($_POST['sdp_return_url'])) : '';

        if (!empty($url)) {
            $url = wp_validate_redirect($url, home_url('/'));
        }

        if (empty($url)) {
            $url = wp_get_referer();
        }

        if (!$url) {
            $url = home_url('/');
        }

        $url = add_query_arg(
            array(
                'sdp_notice_type' => rawurlencode($type),
                'sdp_notice_message' => rawurlencode($message),
            ),
            $url
        );

        wp_safe_redirect($url);
        exit;
    }

    private function handle_registration($role)
    {
        if (!$this->nonce_ok('sdp_register_nonce')) {
            $this->redirect_with_message('error', 'Varnostno preverjanje ni uspelo. Poskusite znova.');
        }

        $first_name = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
        $last_name = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $requested_username = isset($_POST['username']) ? sanitize_user(wp_unslash($_POST['username']), true) : '';
        $password = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
        $password_confirm = isset($_POST['password_confirm']) ? wp_unslash($_POST['password_confirm']) : '';
        $terms = isset($_POST['terms']) ? (int) $_POST['terms'] : 0;
        $privacy = isset($_POST['privacy']) ? (int) $_POST['privacy'] : 0;

        $username_candidates = $this->build_username_candidates($first_name, $last_name);
        $username = '';

        if (!empty($requested_username)) {
            if (!in_array($requested_username, $username_candidates, true)) {
                $this->redirect_with_message('error', 'Izberite predlagano uporabniško ime.');
            }

            $username = $requested_username;
        }

        if (empty($username)) {
            $username = $this->pick_first_available_username($username_candidates);
        }

        if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
            $this->redirect_with_message('error', 'Prosimo, izpolnite vsa obvezna polja.');
        }

        if (empty($username)) {
            $this->redirect_with_message('error', 'Za ta račun ni mogoče pripraviti prostega uporabniškega imena. Poskusite znova.');
        }

        if (!is_email($email)) {
            $this->redirect_with_message('error', 'Vnesite veljaven e-poštni naslov.');
        }

        if ($password !== $password_confirm) {
            $this->redirect_with_message('error', 'Gesli se ne ujemata.');
        }

        if (strlen($password) < 8) {
            $this->redirect_with_message('error', 'Geslo mora vsebovati najmanj 8 znakov.');
        }

        if (!$terms || !$privacy) {
            $this->redirect_with_message('error', 'Za nadaljevanje morate potrditi pogoje in zasebnost.');
        }

        if (username_exists($username)) {
            $this->redirect_with_message('error', 'To uporabniško ime je že zasedeno.');
        }

        if (email_exists($email)) {
            $this->redirect_with_message('error', 'Ta e-poštni naslov je že v uporabi.');
        }

        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            $this->redirect_with_message('error', 'Računa ni bilo mogoče ustvariti. Poskusite ponovno.');
        }

        $user = new WP_User($user_id);
        $user->set_role($role);

        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, self::META_STATUS, 'pending');
        update_user_meta($user_id, self::META_ROLE_TYPE, $role);
        update_user_meta($user_id, 'sdp_phone', $phone);
        update_user_meta($user_id, 'sdp_privacy_accepted_at', current_time('mysql'));
        update_user_meta($user_id, 'sdp_terms_accepted_at', current_time('mysql'));

        if ($role === self::ATHLETE_ROLE) {
            $birth_date = isset($_POST['birth_date']) ? sanitize_text_field(wp_unslash($_POST['birth_date'])) : '';
            $gender = isset($_POST['gender']) ? sanitize_text_field(wp_unslash($_POST['gender'])) : '';

            update_user_meta($user_id, 'sdp_birth_date', $birth_date);
            update_user_meta($user_id, 'sdp_gender', $gender);
        }

        if ($role === self::PARENT_ROLE) {
            $child_info = isset($_POST['child_info']) ? sanitize_textarea_field(wp_unslash($_POST['child_info'])) : '';
            $notes = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';

            update_user_meta($user_id, self::META_CHILD_INFO, $child_info);
            update_user_meta($user_id, 'sdp_notes', $notes);
        }

        $this->send_user_registration_confirmation($user_id, $role);
        $this->send_admin_registration_notice($user_id, $role);

        $this->redirect_with_message('success', 'Registracija je uspela. Zdaj se lahko prijavite spodaj.');
    }

    private function build_username_candidates($first_name, $last_name)
    {
        $first_raw = (string) $first_name;
        $last_raw = (string) $last_name;

        if (function_exists('mb_strtolower')) {
            $first_raw = mb_strtolower($first_raw, 'UTF-8');
            $last_raw = mb_strtolower($last_raw, 'UTF-8');
        } else {
            $first_raw = strtolower($first_raw);
            $last_raw = strtolower($last_raw);
        }

        $first = sanitize_user(remove_accents($first_raw), true);
        $last = sanitize_user(remove_accents($last_raw), true);

        if ($first === '' || $last === '') {
            return array();
        }

        $first_initial = substr($first, 0, 1);
        $last_initial = substr($last, 0, 1);

        $patterns = array(
            $first . '.' . $last,
            $first . $last,
            $first_initial . $last,
            $first . $last_initial,
            $last . '.' . $first,
            $first . '-' . $last,
        );

        $candidates = array();

        foreach ($patterns as $pattern) {
            $sanitized = sanitize_user($pattern, true);

            if ($sanitized === '') {
                continue;
            }

            $candidates[] = $sanitized;
        }

        $candidates = array_values(array_unique($candidates));

        $extended_candidates = $candidates;

        foreach ($candidates as $candidate) {
            for ($i = 1; $i <= 20; $i++) {
                $extended_candidates[] = $candidate . $i;
            }
        }

        return array_values(array_unique($extended_candidates));
    }

    private function pick_first_available_username($candidates)
    {
        foreach ($candidates as $candidate) {
            if (!username_exists($candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    private function handle_login()
    {
        if (!$this->nonce_ok('sdp_login_nonce')) {
            $this->redirect_with_message('error', 'Varnostno preverjanje ni uspelo.');
        }

        $login = isset($_POST['login']) ? sanitize_text_field(wp_unslash($_POST['login'])) : '';
        $password = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
        $remember = !empty($_POST['remember']);

        if (empty($login) || empty($password)) {
            $this->redirect_with_message('error', 'Vnesite uporabniško ime/e-pošto in geslo.');
        }

        $creds = array(
            'user_login' => $login,
            'user_password' => $password,
            'remember' => $remember,
        );

        $user = wp_signon($creds, is_ssl());

        if (is_wp_error($user)) {
            $this->redirect_with_message('error', 'Prijava ni uspela. Preverite podatke in poskusite znova.');
        }

        wp_safe_redirect($this->get_dashboard_url());
        exit;
    }

    private function handle_profile_update()
    {
        if (!is_user_logged_in()) {
            $this->redirect_with_message('error', 'Za urejanje profila se morate prijaviti.');
        }

        if (!$this->nonce_ok('sdp_profile_nonce')) {
            $this->redirect_with_message('error', 'Varnostno preverjanje ni uspelo. Poskusite znova.');
        }

        $user_id = get_current_user_id();
        $first_name = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
        $last_name = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';

        if ($first_name === '' || $last_name === '' || $email === '') {
            $this->redirect_with_message('error', 'Ime, priimek in e-poštni naslov so obvezni.');
        }

        if (!is_email($email)) {
            $this->redirect_with_message('error', 'Vnesite veljaven e-poštni naslov.');
        }

        $existing_email_user_id = email_exists($email);

        if ($existing_email_user_id && (int) $existing_email_user_id !== (int) $user_id) {
            $this->redirect_with_message('error', 'Ta e-poštni naslov je že v uporabi.');
        }

        $update_result = wp_update_user(
            array(
                'ID' => $user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => trim($first_name . ' ' . $last_name),
                'user_email' => $email,
            )
        );

        if (is_wp_error($update_result)) {
            $this->redirect_with_message('error', 'Profila ni bilo mogoče posodobiti. Poskusite ponovno.');
        }

        update_user_meta($user_id, 'sdp_phone', $phone);

        $user = get_user_by('id', $user_id);
        $role = $user instanceof WP_User ? reset($user->roles) : '';

        if ($role === self::ATHLETE_ROLE) {
            $birth_date = isset($_POST['birth_date']) ? sanitize_text_field(wp_unslash($_POST['birth_date'])) : '';
            $gender = isset($_POST['gender']) ? sanitize_text_field(wp_unslash($_POST['gender'])) : '';

            update_user_meta($user_id, 'sdp_birth_date', $birth_date);
            update_user_meta($user_id, 'sdp_gender', $gender);
        }

        if ($role === self::PARENT_ROLE) {
            $child_info = isset($_POST['child_info']) ? sanitize_textarea_field(wp_unslash($_POST['child_info'])) : '';
            $notes = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';

            update_user_meta($user_id, self::META_CHILD_INFO, $child_info);
            update_user_meta($user_id, 'sdp_notes', $notes);
        }

        $this->redirect_with_message('success', 'Profil je uspešno posodobljen.');
    }

    private function handle_forgot_password()
    {
        if (!$this->nonce_ok('sdp_forgot_nonce')) {
            $this->redirect_with_message('error', 'Varnostno preverjanje ni uspelo.');
        }

        $user_login = isset($_POST['user_login']) ? sanitize_text_field(wp_unslash($_POST['user_login'])) : '';

        if (empty($user_login)) {
            $this->redirect_with_message('error', 'Vnesite uporabniško ime ali e-poštni naslov.');
        }

        $result = retrieve_password($user_login);

        if (is_wp_error($result)) {
            $this->redirect_with_message('error', 'Pošiljanje povezave ni uspelo. Preverite vnos.');
        }

        $this->redirect_with_message('success', 'Povezava za ponastavitev gesla je bila poslana.');
    }

    private function handle_reset_password()
    {
        if (!$this->nonce_ok('sdp_reset_nonce')) {
            $this->redirect_with_message('error', 'Varnostno preverjanje ni uspelo.');
        }

        $key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
        $login = isset($_POST['login']) ? sanitize_text_field(wp_unslash($_POST['login'])) : '';
        $password = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
        $password_confirm = isset($_POST['password_confirm']) ? wp_unslash($_POST['password_confirm']) : '';

        if (empty($key) || empty($login)) {
            $this->redirect_with_message('error', 'Povezava za ponastavitev ni veljavna.');
        }

        if (strlen($password) < 8) {
            $this->redirect_with_message('error', 'Geslo mora vsebovati najmanj 8 znakov.');
        }

        if ($password !== $password_confirm) {
            $this->redirect_with_message('error', 'Gesli se ne ujemata.');
        }

        $user = check_password_reset_key($key, $login);

        if (is_wp_error($user)) {
            $this->redirect_with_message('error', 'Povezava za ponastavitev je potekla ali ni veljavna.');
        }

        reset_password($user, $password);

        $this->redirect_with_message('success', 'Geslo je bilo uspešno spremenjeno. Zdaj se lahko prijavite.');
    }

    public function block_pending_users($user, $username, $password)
    {
        if ($user instanceof WP_User) {
            $status = get_user_meta($user->ID, self::META_STATUS, true);

            if ($status === 'pending') {
                return $user;
            }

            if ($status === 'rejected') {
                return new WP_Error('rejected_account', 'Vaša registracija je bila zavrnjena. Za pomoč nas kontaktirajte.');
            }
        }

        return $user;
    }

    public function register_admin_pages()
    {
        add_menu_page(
            'SD Portal',
            'SD Portal',
            'manage_options',
            'sdp-portal-users',
            array($this, 'render_portal_users_page'),
            'dashicons-groups'
        );

        add_submenu_page(
            'sdp-portal-users',
            'Users',
            'Users',
            'manage_options',
            'sdp-portal-users',
            array($this, 'render_portal_users_page')
        );

        add_submenu_page(
            'sdp-portal-users',
            'Settings',
            'Settings',
            'manage_options',
            'sdp-portal-settings',
            array($this, 'render_portal_settings_page')
        );
    }

    public function render_portal_users_page()
    {
        if (!current_user_can('list_users')) {
            wp_die('You do not have permission to access this page.');
        }

        $users_url = add_query_arg('sdp_portal', '1', admin_url('users.php'));
        wp_safe_redirect($users_url);
        exit;
    }

    public function filter_users_admin_lists($query)
    {
        if (!is_admin() || !($query instanceof WP_User_Query)) {
            return;
        }

        global $pagenow;

        if ($pagenow !== 'users.php') {
            return;
        }

        $portal_users_view = isset($_GET['sdp_portal']) && sanitize_text_field(wp_unslash($_GET['sdp_portal'])) === '1';

        if ($portal_users_view) {
            $query->set('role__in', array(self::PARENT_ROLE, self::ATHLETE_ROLE));
            return;
        }

        $excluded_roles = $query->get('role__not_in');
        $excluded_roles = is_array($excluded_roles) ? $excluded_roles : array();
        $excluded_roles[] = self::PARENT_ROLE;
        $excluded_roles[] = self::ATHLETE_ROLE;

        $query->set('role__not_in', array_values(array_unique($excluded_roles)));
    }

    public function render_portal_settings_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        $admin_email = $this->get_admin_notification_email();
        $settings_updated = isset($_GET['sdp_settings_updated']) ? sanitize_text_field(wp_unslash($_GET['sdp_settings_updated'])) : '';
        $settings_error = isset($_GET['sdp_settings_error']) ? sanitize_text_field(wp_unslash($_GET['sdp_settings_error'])) : '';

        echo '<div class="wrap">';
        echo '<h1>SD Portal Settings</h1>';

        if ($settings_updated === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        }

        if ($settings_error === 'invalid_email') {
            echo '<div class="notice notice-error"><p>Please enter a valid admin email address.</p></div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('sdp_portal_settings');
        echo '<input type="hidden" name="action" value="sdp_portal_save_settings" />';

        echo '<table class="form-table" role="presentation">';
        echo '<tr>';
        echo '<th scope="row"><label for="sdp_admin_notification_email">Admin Email</label></th>';
        echo '<td>';
        echo '<input name="sdp_admin_notification_email" id="sdp_admin_notification_email" type="email" class="regular-text" value="' . esc_attr($admin_email) . '" required />';
        echo '<p class="description">Notification emails about new registrations will be sent to this address.</p>';
        echo '</td>';
        echo '</tr>';
        echo '</table>';

        submit_button('Save Settings');

        echo '</form>';
        echo '</div>';
    }

    public function handle_admin_settings_save()
    {
        if (!current_user_can('manage_options')) {
            wp_die('Forbidden');
        }

        check_admin_referer('sdp_portal_settings');

        $admin_email = isset($_POST['sdp_admin_notification_email']) ? sanitize_email(wp_unslash($_POST['sdp_admin_notification_email'])) : '';
        $redirect_url = admin_url('admin.php?page=sdp-portal-settings');

        if (!$admin_email || !is_email($admin_email)) {
            wp_safe_redirect(add_query_arg('sdp_settings_error', 'invalid_email', $redirect_url));
            exit;
        }

        update_option(self::OPTION_ADMIN_NOTIFICATION_EMAIL, $admin_email);

        wp_safe_redirect(add_query_arg('sdp_settings_updated', '1', $redirect_url));
        exit;
    }

    private function get_admin_notification_email()
    {
        $admin_email = get_option(self::OPTION_ADMIN_NOTIFICATION_EMAIL, '');

        if ($admin_email && is_email($admin_email)) {
            return $admin_email;
        }

        return (string) get_option('admin_email');
    }

    public function render_pending_accounts_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        $pending_users = get_users(
            array(
                'meta_key' => self::META_STATUS,
                'meta_value' => 'pending',
                'number' => 200,
            )
        );

        echo '<div class="wrap">';
        echo '<h1>Pending Accounts</h1>';

        if (isset($_GET['updated'])) {
            echo '<div class="notice notice-success"><p>Account status updated.</p></div>';
        }

        if (empty($pending_users)) {
            echo '<p>No pending accounts.</p>';
            echo '</div>';
            return;
        }

        echo '<table class="widefat striped">';
        echo '<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead><tbody>';

        foreach ($pending_users as $pending_user) {
            $role = get_user_meta($pending_user->ID, self::META_ROLE_TYPE, true);
            $first_name = get_user_meta($pending_user->ID, 'first_name', true);
            $last_name = get_user_meta($pending_user->ID, 'last_name', true);
            $display_name = trim($first_name . ' ' . $last_name);

            $approve_url = wp_nonce_url(
                admin_url('admin-post.php?action=sdp_account_action&mode=approve&user_id=' . (int) $pending_user->ID),
                'sdp_account_action'
            );

            $reject_url = wp_nonce_url(
                admin_url('admin-post.php?action=sdp_account_action&mode=reject&user_id=' . (int) $pending_user->ID),
                'sdp_account_action'
            );

            echo '<tr>';
            echo '<td>' . esc_html((string) $pending_user->ID) . '</td>';
            echo '<td>' . esc_html($display_name ?: $pending_user->display_name) . '</td>';
            echo '<td>' . esc_html($pending_user->user_email) . '</td>';
            echo '<td>' . esc_html($role) . '</td>';
            echo '<td>';
            echo '<a class="button button-primary" href="' . esc_url($approve_url) . '">Approve</a> ';
            echo '<a class="button" href="' . esc_url($reject_url) . '">Reject</a>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    public function handle_admin_account_action()
    {
        if (!current_user_can('manage_options')) {
            wp_die('Forbidden');
        }

        check_admin_referer('sdp_account_action');

        $mode = isset($_GET['mode']) ? sanitize_key(wp_unslash($_GET['mode'])) : '';
        $user_id = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

        if (!$user_id || !in_array($mode, array('approve', 'reject'), true)) {
            wp_safe_redirect(admin_url('admin.php?page=sdp-accounts'));
            exit;
        }

        update_user_meta($user_id, self::META_STATUS, $mode === 'approve' ? 'approved' : 'rejected');

        wp_safe_redirect(admin_url('admin.php?page=sdp-accounts&updated=1'));
        exit;
    }

    public function render_account_links_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        $parents = get_users(
            array(
                'role' => self::PARENT_ROLE,
                'number' => 500,
            )
        );

        $athletes = get_users(
            array(
                'role' => self::ATHLETE_ROLE,
                'number' => 500,
            )
        );

        echo '<div class="wrap">';
        echo '<h1>Parent-Athlete Links</h1>';
        echo '<p>Create or remove links between parent and athlete accounts. This is admin-only.</p>';

        if (isset($_GET['linked'])) {
            echo '<div class="notice notice-success"><p>Link action completed.</p></div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('sdp_link_action');
        echo '<input type="hidden" name="action" value="sdp_link_action" />';

        echo '<table class="form-table">';

        echo '<tr><th><label for="parent_id">Parent</label></th><td><select name="parent_id" id="parent_id" required>';
        echo '<option value="">Select parent</option>';
        foreach ($parents as $parent) {
            echo '<option value="' . esc_attr((string) $parent->ID) . '">' . esc_html($parent->display_name . ' (' . $parent->user_email . ')') . '</option>';
        }
        echo '</select></td></tr>';

        echo '<tr><th><label for="athlete_id">Athlete</label></th><td><select name="athlete_id" id="athlete_id" required>';
        echo '<option value="">Select athlete</option>';
        foreach ($athletes as $athlete) {
            echo '<option value="' . esc_attr((string) $athlete->ID) . '">' . esc_html($athlete->display_name . ' (' . $athlete->user_email . ')') . '</option>';
        }
        echo '</select></td></tr>';

        echo '<tr><th><label for="mode">Action</label></th><td><select name="mode" id="mode">';
        echo '<option value="link">Link</option>';
        echo '<option value="unlink">Unlink</option>';
        echo '</select></td></tr>';

        echo '</table>';

        submit_button('Save Link Action');

        echo '</form>';
        echo '</div>';
    }

    public function handle_admin_link_action()
    {
        if (!current_user_can('manage_options')) {
            wp_die('Forbidden');
        }

        check_admin_referer('sdp_link_action');

        $parent_id = isset($_POST['parent_id']) ? (int) $_POST['parent_id'] : 0;
        $athlete_id = isset($_POST['athlete_id']) ? (int) $_POST['athlete_id'] : 0;
        $mode = isset($_POST['mode']) ? sanitize_key(wp_unslash($_POST['mode'])) : 'link';

        if (!$parent_id || !$athlete_id || !in_array($mode, array('link', 'unlink'), true)) {
            wp_safe_redirect(admin_url('admin.php?page=sdp-account-links'));
            exit;
        }

        $parent_athlete_ids = get_user_meta($parent_id, self::META_ATHLETE_IDS, true);
        $athlete_parent_ids = get_user_meta($athlete_id, self::META_PARENT_IDS, true);

        $parent_athlete_ids = is_array($parent_athlete_ids) ? $parent_athlete_ids : array();
        $athlete_parent_ids = is_array($athlete_parent_ids) ? $athlete_parent_ids : array();

        if ($mode === 'link') {
            if (!in_array($athlete_id, $parent_athlete_ids, true)) {
                $parent_athlete_ids[] = $athlete_id;
            }

            if (!in_array($parent_id, $athlete_parent_ids, true)) {
                $athlete_parent_ids[] = $parent_id;
            }
        } else {
            $parent_athlete_ids = array_values(array_diff($parent_athlete_ids, array($athlete_id)));
            $athlete_parent_ids = array_values(array_diff($athlete_parent_ids, array($parent_id)));
        }

        update_user_meta($parent_id, self::META_ATHLETE_IDS, $parent_athlete_ids);
        update_user_meta($athlete_id, self::META_PARENT_IDS, $athlete_parent_ids);

        wp_safe_redirect(admin_url('admin.php?page=sdp-account-links&linked=1'));
        exit;
    }

    private function get_notice_html()
    {
        $notice = $this->get_notice_data();
        $type = $notice['type'];
        $message = $notice['message'];

        if (!$type || !$message) {
            return '';
        }

        $class = $type === 'success' ? 'sdp-notice-success' : 'sdp-notice-error';

        $html = '<div class="sdp-notice ' . esc_attr($class) . '">' . esc_html($message) . '</div>';

        return $html;
    }

    private function get_notice_data()
    {
        $type = isset($_GET['sdp_notice_type']) ? sanitize_text_field(wp_unslash($_GET['sdp_notice_type'])) : '';
        $message = isset($_GET['sdp_notice_message']) ? sanitize_text_field(wp_unslash($_GET['sdp_notice_message'])) : '';

        return array(
            'type' => $type,
            'message' => $message,
        );
    }

    private function is_registration_success_notice()
    {
        $notice = $this->get_notice_data();

        return $notice['type'] === 'success' && strpos($notice['message'], 'Registracija je uspela') !== false;
    }

    public function render_athlete_registration()
    {
        $show_login_after_registration = $this->is_registration_success_notice();

        ob_start();
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <?php if ($show_login_after_registration) : ?>
                    <h2>Prijava</h2>
                    <form method="post" class="sdp-form-grid">
                        <?php wp_nonce_field('sdp_login_nonce'); ?>
                        <input type="hidden" name="sdp_action" value="login" />
                        <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                        <label>Uporabniško ime ali e-pošta *<input name="login" type="text" required></label>
                        <label>Geslo *<input name="password" type="password" required></label>
                        <label class="sdp-check"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

                        <button type="submit" class="sdp-btn-primary">Prijava</button>
                    </form>
                    <p class="sdp-helper-links"><a href="<?php echo esc_url(home_url('/uporabniski-portal/pozabljeno-geslo/')); ?>">Ste pozabili geslo?</a></p>
                <?php else : ?>
                    <h2>Registracija atleta</h2>
                    <form method="post" class="sdp-form-grid sdp-registration-form">
                        <?php wp_nonce_field('sdp_register_nonce'); ?>
                        <input type="hidden" name="sdp_action" value="register_athlete" />
                        <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                        <label>Ime *<input name="first_name" type="text" required></label>
                        <label>Priimek *<input name="last_name" type="text" required></label>
                        <label>Datum rojstva *<input name="birth_date" type="date" required></label>
                        <label>Spol
                            <select name="gender">
                                <option value="">Izberi</option>
                                <option value="moski">Moški</option>
                                <option value="zenski">Ženski</option>
                                <option value="drugo">Drugo</option>
                            </select>
                        </label>
                        <label>E-poštni naslov *<input name="email" type="email" required></label>
                        <label>Telefon starša/skrbnika <input name="phone" type="text"></label>
                        <label>Uporabniško ime *
                            <select name="username" class="sdp-username-select" required>
                                <option value="">Najprej vnesite ime in priimek</option>
                            </select>
                        </label>
                        <p class="sdp-username-help">Predlogi uporabniškega imena se pripravijo samodejno glede na ime in priimek.</p>
                        <label>Geslo *<input name="password" type="password" minlength="8" required></label>
                        <label>Potrditev gesla *<input name="password_confirm" type="password" minlength="8" required></label>

                        <label class="sdp-check"><input type="checkbox" name="privacy" value="1" required> Soglašam s politiko zasebnosti *</label>
                        <label class="sdp-check"><input type="checkbox" name="terms" value="1" required> Strinjam se s pogoji uporabe *</label>

                        <button type="submit" class="sdp-btn-primary">Ustvari račun</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_parent_registration()
    {
        $show_login_after_registration = $this->is_registration_success_notice();

        ob_start();
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <?php if ($show_login_after_registration) : ?>
                    <h2>Prijava</h2>
                    <form method="post" class="sdp-form-grid">
                        <?php wp_nonce_field('sdp_login_nonce'); ?>
                        <input type="hidden" name="sdp_action" value="login" />
                        <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                        <label>Uporabniško ime ali e-pošta *<input name="login" type="text" required></label>
                        <label>Geslo *<input name="password" type="password" required></label>
                        <label class="sdp-check"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

                        <button type="submit" class="sdp-btn-primary">Prijava</button>
                    </form>
                    <p class="sdp-helper-links"><a href="<?php echo esc_url(home_url('/uporabniski-portal/pozabljeno-geslo/')); ?>">Ste pozabili geslo?</a></p>
                <?php else : ?>
                    <h2>Registracija starša</h2>
                    <form method="post" class="sdp-form-grid sdp-registration-form">
                        <?php wp_nonce_field('sdp_register_nonce'); ?>
                        <input type="hidden" name="sdp_action" value="register_parent" />
                        <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                        <label>Ime *<input name="first_name" type="text" required></label>
                        <label>Priimek *<input name="last_name" type="text" required></label>
                        <label>E-poštni naslov *<input name="email" type="email" required></label>
                        <label>Telefon <input name="phone" type="text"></label>
                        <label>Uporabniško ime *
                            <select name="username" class="sdp-username-select" required>
                                <option value="">Najprej vnesite ime in priimek</option>
                            </select>
                        </label>
                        <p class="sdp-username-help">Predlogi uporabniškega imena se pripravijo samodejno glede na ime in priimek.</p>
                        <label>Geslo *<input name="password" type="password" minlength="8" required></label>
                        <label>Potrditev gesla *<input name="password_confirm" type="password" minlength="8" required></label>
                        <label>Ime in priimek otroka (informativno)
                            <textarea name="child_info" rows="2" placeholder="Npr. Ana Novak"></textarea>
                        </label>
                        <label>Opombe
                            <textarea name="notes" rows="3" placeholder="Dodatne informacije"></textarea>
                        </label>

                        <label class="sdp-check"><input type="checkbox" name="privacy" value="1" required> Soglašam s politiko zasebnosti *</label>
                        <label class="sdp-check"><input type="checkbox" name="terms" value="1" required> Strinjam se s pogoji uporabe *</label>

                        <button type="submit" class="sdp-btn-primary">Ustvari račun</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_login_form()
    {
        ob_start();
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <h2>Prijava</h2>
                <form method="post" class="sdp-form-grid">
                    <?php wp_nonce_field('sdp_login_nonce'); ?>
                    <input type="hidden" name="sdp_action" value="login" />
                    <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                    <label>Uporabniško ime ali e-pošta *<input name="login" type="text" required></label>
                    <label>Geslo *<input name="password" type="password" required></label>
                    <label class="sdp-check"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

                    <button type="submit" class="sdp-btn-primary">Prijava</button>
                </form>
                <p class="sdp-helper-links"><a href="?show=forgot">Ste pozabili geslo?</a></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_forgot_password_form()
    {
        ob_start();
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <h2>Pozabljeno geslo</h2>
                <form method="post" class="sdp-form-grid">
                    <?php wp_nonce_field('sdp_forgot_nonce'); ?>
                    <input type="hidden" name="sdp_action" value="forgot_password" />
                    <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />

                    <label>Uporabniško ime ali e-pošta *<input name="user_login" type="text" required></label>

                    <button type="submit" class="sdp-btn-primary">Pošlji povezavo za ponastavitev</button>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_reset_password_form()
    {
        $key = isset($_GET['key']) ? sanitize_text_field(wp_unslash($_GET['key'])) : '';
        $login = isset($_GET['login']) ? sanitize_text_field(wp_unslash($_GET['login'])) : '';

        ob_start();
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <h2>Ponastavitev gesla</h2>
                <form method="post" class="sdp-form-grid">
                    <?php wp_nonce_field('sdp_reset_nonce'); ?>
                    <input type="hidden" name="sdp_action" value="reset_password" />
                    <input type="hidden" name="sdp_return_url" value="<?php echo esc_url(get_permalink()); ?>" />
                    <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>" />
                    <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>" />

                    <label>Novo geslo *<input name="password" type="password" minlength="8" required></label>
                    <label>Potrdi novo geslo *<input name="password_confirm" type="password" minlength="8" required></label>

                    <button type="submit" class="sdp-btn-primary">Shrani novo geslo</button>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_dashboard()
    {
        ob_start();

        if (!is_user_logged_in()) {
            $login_url = home_url('/uporabniski-portal/prijava/');
            ?>
            <div class="sdp-auth-wrap">
                <div class="sdp-auth-card">
                    <h2>Uporabniški portal</h2>
                    <p>Za ogled portala se morate prijaviti.</p>
                    <p class="sdp-helper-links"><a href="<?php echo esc_url($login_url); ?>">Pojdi na prijavo</a></p>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        $user_id = get_current_user_id();
        $user = get_user_by('id', $user_id);

        if (!$user) {
            return '';
        }

        $dashboard_url = get_permalink();
        $tab = isset($_GET['sdp_tab']) ? sanitize_key(wp_unslash($_GET['sdp_tab'])) : 'overview';

        if (!in_array($tab, array('overview', 'profile'), true)) {
            $tab = 'overview';
        }

        $overview_url = add_query_arg('sdp_tab', 'overview', $dashboard_url);
        $profile_url = add_query_arg('sdp_tab', 'profile', $dashboard_url);

        $role = reset($user->roles);
        $first_name = get_user_meta($user_id, 'first_name', true);
        $last_name = get_user_meta($user_id, 'last_name', true);
        $email = $user->user_email;
        $phone = get_user_meta($user_id, 'sdp_phone', true);
        $birth_date = get_user_meta($user_id, 'sdp_birth_date', true);
        $gender = get_user_meta($user_id, 'sdp_gender', true);
        $child_info = get_user_meta($user_id, self::META_CHILD_INFO, true);
        $notes = get_user_meta($user_id, 'sdp_notes', true);
        ?>
        <div class="sdp-auth-wrap">
            <?php echo wp_kses_post($this->get_notice_html()); ?>
            <div class="sdp-auth-card">
                <h2>Uporabniški portal</h2>
                <nav class="sdp-dashboard-nav" aria-label="Navigacija uporabniškega portala">
                    <a class="sdp-dashboard-tab <?php echo $tab === 'overview' ? 'is-active' : ''; ?>" href="<?php echo esc_url($overview_url); ?>">Pregled</a>
                    <a class="sdp-dashboard-tab <?php echo $tab === 'profile' ? 'is-active' : ''; ?>" href="<?php echo esc_url($profile_url); ?>">Uredi profil</a>
                </nav>

                <?php if ($tab === 'overview') : ?>
                    <div class="sdp-dashboard-panel">
                        <p class="sdp-profile-intro">Pozdravljeni, <?php echo esc_html($first_name ? $first_name : $user->display_name); ?>. Dobrodošli v portalu ŠD Pohorje.</p>
                        <p class="sdp-profile-username"><strong>Vloga:</strong> <?php echo esc_html($role); ?></p>
                        <p class="sdp-profile-intro">Uporabite navigacijo zgoraj za urejanje profila. Nove funkcionalnosti bomo dodajali postopoma.</p>
                    </div>
                <?php endif; ?>

                <?php if ($tab === 'profile') : ?>
                    <div class="sdp-dashboard-panel">
                        <h3>Moj profil</h3>
                        <p class="sdp-profile-intro">Tukaj lahko posodobite svoje podatke. Uporabniškega imena ni mogoče spreminjati.</p>
                        <p class="sdp-profile-username"><strong>Uporabniško ime:</strong> <?php echo esc_html($user->user_login); ?></p>

                        <form method="post" class="sdp-form-grid">
                            <?php wp_nonce_field('sdp_profile_nonce'); ?>
                            <input type="hidden" name="sdp_action" value="update_profile" />
                            <input type="hidden" name="sdp_return_url" value="<?php echo esc_url($profile_url); ?>" />

                            <label>Ime *<input name="first_name" type="text" value="<?php echo esc_attr($first_name); ?>" required></label>
                            <label>Priimek *<input name="last_name" type="text" value="<?php echo esc_attr($last_name); ?>" required></label>
                            <label>E-poštni naslov *<input name="email" type="email" value="<?php echo esc_attr($email); ?>" required></label>
                            <label>Telefon <input name="phone" type="text" value="<?php echo esc_attr($phone); ?>"></label>

                            <?php if ($role === self::ATHLETE_ROLE) : ?>
                                <label>Datum rojstva <input name="birth_date" type="date" value="<?php echo esc_attr($birth_date); ?>"></label>
                                <label>Spol
                                    <select name="gender">
                                        <option value="" <?php selected($gender, ''); ?>>Izberi</option>
                                        <option value="moski" <?php selected($gender, 'moski'); ?>>Moški</option>
                                        <option value="zenski" <?php selected($gender, 'zenski'); ?>>Ženski</option>
                                        <option value="drugo" <?php selected($gender, 'drugo'); ?>>Drugo</option>
                                    </select>
                                </label>
                            <?php endif; ?>

                            <?php if ($role === self::PARENT_ROLE) : ?>
                                <label>Ime in priimek otroka (informativno)
                                    <textarea name="child_info" rows="2" placeholder="Npr. Ana Novak"><?php echo esc_textarea($child_info); ?></textarea>
                                </label>
                                <label>Opombe
                                    <textarea name="notes" rows="3" placeholder="Dodatne informacije"><?php echo esc_textarea($notes); ?></textarea>
                                </label>
                            <?php endif; ?>

                            <button type="submit" class="sdp-btn-primary">Shrani profil</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function send_admin_registration_notice($user_id, $role)
    {
        $admin_email = $this->get_admin_notification_email();
        $user = get_user_by('id', $user_id);

        if (!$admin_email || !$user) {
            return;
        }

        $subject = 'New registration pending approval';
        $message = sprintf(
            "A new account is pending approval.\n\nUser ID: %d\nUsername: %s\nEmail: %s\nRole: %s\n",
            $user->ID,
            $user->user_login,
            $user->user_email,
            $role
        );

        wp_mail($admin_email, $subject, $message);
    }

    private function send_user_registration_confirmation($user_id, $role)
    {
        $user = get_user_by('id', $user_id);

        if (!$user || empty($user->user_email)) {
            return;
        }

        $first_name = get_user_meta($user_id, 'first_name', true);
        $login_url = home_url('/uporabniski-portal/prijava/');
        $portal_url = $this->get_dashboard_url();
        $display_name = $first_name ? $first_name : $user->user_login;

        $role_label = $role === self::ATHLETE_ROLE ? 'atleta' : 'starša';

        $subject = 'ŠD Pohorje: Registracija uspešna';
        $from_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $from_email = sanitize_email(get_option('admin_email'));

        if (!$from_email || !is_email($from_email)) {
            $from_email = 'noreply@' . wp_parse_url(home_url('/'), PHP_URL_HOST);
        }

        $html_message = '
<div style="margin:0;padding:24px;background:#f2f7fb;font-family:Arial,Helvetica,sans-serif;color:#183748;">
    <div style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #d3e3ef;border-radius:14px;overflow:hidden;">
        <div style="background:#356f8c;padding:18px 24px;">
            <h1 style="margin:0;color:#ffffff;font-size:22px;line-height:1.3;">ŠD Pohorje</h1>
        </div>
        <div style="padding:24px;">
            <p style="margin:0 0 14px;font-size:16px;line-height:1.55;">Pozdravljeni, ' . esc_html($display_name) . '!</p>
            <p style="margin:0 0 14px;font-size:16px;line-height:1.55;">Hvala za registracijo ' . esc_html($role_label) . ' v portal ŠD Pohorje.</p>
            <p style="margin:0 0 14px;font-size:16px;line-height:1.55;">Registracija je uspešna. Prijavite se lahko tukaj:</p>
            <p style="margin:0 0 20px;">
                <a href="' . esc_url($login_url) . '" style="display:inline-block;background:#c69a47;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 18px;border-radius:999px;">Na prijavo</a>
            </p>
            <p style="margin:0 0 14px;font-size:15px;line-height:1.55;">Po prijavi boste preusmerjeni v uporabniški portal:</p>
            <p style="margin:0 0 14px;font-size:15px;line-height:1.55;"><a href="' . esc_url($portal_url) . '" style="color:#2f3b45;">' . esc_html($portal_url) . '</a></p>
            <p style="margin:20px 0 0;font-size:14px;line-height:1.55;color:#4b6574;">Lep pozdrav,<br>ekipa ŠD Pohorje</p>
        </div>
    </div>
</div>';

        $text_message = "Pozdravljeni, {$display_name}!\n\n" .
            "Hvala za registracijo {$role_label} v portal ŠD Pohorje.\n" .
            "Registracija je uspešna.\n\n" .
            "Prijava: {$login_url}\n" .
            "Uporabniški portal: {$portal_url}\n\n" .
            "Lep pozdrav,\n" .
            "ekipa ŠD Pohorje";

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        );

        $sent = wp_mail($user->user_email, $subject, $html_message, $headers);

        if (!$sent) {
            $fallback_headers = array('From: ' . $from_name . ' <' . $from_email . '>');
            $sent = wp_mail($user->user_email, $subject, $text_message, $fallback_headers);
        }

        if (!$sent) {
            error_log('SDP Accounts: failed to send registration email to ' . $user->user_email);
        }
    }
}
